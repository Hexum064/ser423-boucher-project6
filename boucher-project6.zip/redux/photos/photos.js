
/*

Author: Branden Boucher
Class: SER423
Project: 6

*/
const photoMap = [
    {
        "albumid": '1',
        "title": "Dookie",
        "url": "https://extrachill.com/wp-content/uploads/2021/11/green-day-dookie-cover-artwork.jpg",
        "thumbnailUrl": "https://extrachill.com/wp-content/uploads/2021/11/green-day-dookie-cover-artwork.jpg",
        "id": 4
    },
    {
        "albumid": '1',
        "title": "Smash",
        "url": "https://upload.wikimedia.org/wikipedia/en/8/80/TheOffspringSmashalbumcover.jpg",
        "thumbnailUrl": "https://upload.wikimedia.org/wikipedia/en/8/80/TheOffspringSmashalbumcover.jpg",
        "id": 5
    },
    {
        "albumid": '5',
        "title": "Punk in Drublic",
        "url": "https://upload.wikimedia.org/wikipedia/en/1/19/NOFX_-_Punk_in_Drublic_cover.jpg",
        "thumbnailUrl": "https://upload.wikimedia.org/wikipedia/en/1/19/NOFX_-_Punk_in_Drublic_cover.jpg",
        "id": 6
    },
];


export default photoMap;